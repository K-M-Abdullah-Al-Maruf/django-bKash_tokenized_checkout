from django.apps import AppConfig


class bKash_tokenized_checkoutConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_bKash_tokenized_chekout"
    label = "tokenized_chekout"